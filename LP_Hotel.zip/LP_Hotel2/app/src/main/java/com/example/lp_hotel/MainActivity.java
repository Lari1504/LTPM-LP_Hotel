package com.example.lp_hotel;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btcriarbanco, btcadastrardados, btcadastrardados2,btexcluirdados, btconsultardados;

    SQLiteDatabase db;
    DialogInterface.OnClickListener diExcluiBanco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btcriarbanco = findViewById(R.id.btcriarbanco);
        btcadastrardados = findViewById(R.id.btcadastrardados);
        btcadastrardados2 = findViewById(R.id.btcadastrardados2);
        btexcluirdados = findViewById(R.id.btexcluirdados);
        btconsultardados = findViewById(R.id.btconsultardados);

        try {
            db = openOrCreateDatabase("banco_dados", Context.MODE_PRIVATE, null);
            db.execSQL("create table if not exists usuario(numreg integer primary key " +
                    "autoincrement, nome text not null ,telefone text not null, email text not null)");
            db.execSQL("create table if not exists Registrar_quarto(numreg integer primary key " +
                    "autoincrement, nome text not null , descricao text)");
        } catch (Exception e) {
            MostraMensagem("Erro ao criar banco : " + e.toString());
        }

        diExcluiBanco = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Exclui as informações do registro na tabela
                db.execSQL("drop table usuario");
                db.execSQL("create table if not exists usuario(numreg integer primary key " +
                        "autoincrement, nome text not null ,telefone text not null, email text not null)");
                MostraMensagem("Usuários excluídos com sucesso!");
            }
        };

        btcadastrardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registraUsuarioActivity = new Intent(MainActivity.this,
                        GravaRegistrosActivity.class);
                MainActivity.this.startActivity(registraUsuarioActivity);
            }
        });
        btcadastrardados2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registraQuartoActivity = new Intent(MainActivity.this,
                       RegistrarquartoActivity.class);
                MainActivity.this.startActivity(registraQuartoActivity);
            }
        });
        btexcluirdados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent excluirDadosActivity = new Intent(MainActivity.this,
                        ConsultaDadosActivity.class);
                MainActivity.this.startActivity(excluirDadosActivity);
            }
        });
        btconsultardados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent consultarUsuarioActivity = new Intent(MainActivity.this,
                        ConsultaDadosActivity.class);
                MainActivity.this.startActivity(consultarUsuarioActivity);
            }
        });
    }


    public void MostraMensagem(String str) {
        AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("Ok", null);
        dialogo.show();
    }
}
