package com.example.lp_hotel;

import android.app.Activity;
import android.os.Bundle;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegistrarquartoActivity extends Activity {
    Button btcadastrardados2;
    EditText ednome;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_quarto);
        btcadastrardados2 = (Button) findViewById(R.id.btcadastrardados2);
        ednome = (EditText) findViewById(R.id.ednome);
        try {
            db = openOrCreateDatabase("banco_dados", Context.MODE_PRIVATE, null);
        }
        catch (Exception e)
        {
            MostraMensagem("Erro:" + e.toString());
        }
        btcadastrardados2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View argo) {
                String nome = ednome.getText().toString();
                ContentValues valor = new ContentValues();
                valor.put("nome", nome);
                try {
                    db.insert("usuarios", null, valor); MostraMensagem("Dados cadastrados com sucesso");
                }
                catch (Exception e)
                {
                    MostraMensagem("Erro:" + e.toString());
                }
            }
        });
    }
    public void MostraMensagem (String str)
    {
        AlertDialog.Builder dialogo = new
        AlertDialog.Builder(RegistrarquartoActivity.this);
        dialogo.setTitle("Aviso");
        dialogo.setMessage(str);
        dialogo.setNeutralButton("OK", null);
        dialogo.show();
    }
}